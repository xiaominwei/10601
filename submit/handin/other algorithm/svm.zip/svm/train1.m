function [Model1] = train1(X,Y)
    feas = [];
    for i = 1 : size(X,1)
        feas = [feas;naivehog(reshape(X(i,:),[32,32,3]))'];
    end
    Model1 = svmTrain(feas,Y);
    save('Model1.mat', 'Model1');
end
