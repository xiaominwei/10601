function labels = classify1(Model,X)
    feas = [];
    for i = 1 : size(X,1)
        feas = [feas;naivehog(reshape(X(i,:),[32,32,3]))'];
        i
    end
    
    margins = feas * (Model.w)'+ repmat((Model.b)',[size(feas,1),1]);
    [~,labels] = max(margins,[],2);
    
    labels = labels - ones(size(labels));
    
end 
