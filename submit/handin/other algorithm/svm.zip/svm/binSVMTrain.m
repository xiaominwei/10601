function [w, b] = binSVMTrain(feas, tempY, epsilon)
    H = (feas * feas') .* (tempY * tempY');
    f = ones (size(tempY, 1), 1);
    
    A = tempY';
    b = 0;
    
    lb = zeros(size(tempY, 1), 1);
    ub = zeros(size(tempY, 1), 1) + epsilon + 8*epsilon*(tempY == 1);
   
    alpha=quadprog(double(H),-1*f,[],[],double(A),b,lb,ub,[],optimset('Algorithm','interior-point-convex','Display','off'));
    w = (alpha .* tempY)' * feas;
    sv_idx = find((alpha>1e-5)&(alpha<epsilon - 1e-5));
    b_all = 1 ./ tempY -(w*feas')';
    b = mean(b_all(sv_idx));
end
