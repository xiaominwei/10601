function Model = svmTrain(X, Y, epsilon)
    if nargin < 3
        epsilon = 0.1;
    end
    Y = single(Y);
    maxy = max(Y);
    miny = min(Y);
    classCount = maxy - miny + 1;
    Model.w = [];
    Model.b = [];
    
    % use 1 vs rest to implement multi-class svm
    for i=1:classCount
        tempY = Y;
        tempY(tempY == i-1, 1) = 1;
        tempY(tempY ~= i-1, 1) = -1;
        [w, b] = binSVMTrain(X, tempY, epsilon);
        Model.w = [Model.w;w];
        Model.b = [Model.b;b];
    end
    
end
