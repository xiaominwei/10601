function [ Y ] = sfmClassify( softmaxModel, XTest )
%SFMCLASSIFY Summary of this function goes here
%   Detailed explanation goes here

[Y] = softmaxPredict(softmaxModel, XTest);
end

function [pred] = softmaxPredict(softmaxModel, data)
theta = softmaxModel.theta;
M = exp(theta*data);
M = bsxfun(@rdivide, M, sum(M));

[~, pred] = max(M);

end

