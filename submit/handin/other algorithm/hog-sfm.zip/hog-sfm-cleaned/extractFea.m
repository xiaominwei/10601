function [ XFea ] = extractFea( XImg )

    % uncommnet foloowing to use hog feature
    [ XFea ] = hog_extractFea( XImg );
    load('fea_filt.mat');
    XFea = XFea(:,feaind);

    
    % XFea = double(XImg);
    
    % sparse auto encoder
    %{
    load('sparseModel.mat');
    [ XFea ] = sparseEncode(sparseModel, XImg );
    %}
    
end

