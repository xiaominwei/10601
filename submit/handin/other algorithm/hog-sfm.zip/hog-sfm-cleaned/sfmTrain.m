function [ Model ] = sfmTrain( XTrain,YTrain )
%SFMTRAIN Summary of this function goes here
%   Detailed explanation goes here
numClasses = size(unique(YTrain),1);
lambda = 1e-4;
labels = YTrain;
inputSize = size(XTrain,2);
inputData = XTrain';
[Model] = softmaxTrain(inputSize, numClasses, lambda, inputData, labels);

end

function [softmaxModel] = softmaxTrain(inputSize, numClasses, lambda, inputData, labels, options)

if ~exist('options', 'var')
    options = struct;
end

if ~isfield(options, 'maxIter')
    options.maxIter = 1000;
end

% initialize parameters
theta = 0.005 * randn(numClasses * inputSize, 1);

options.Method = 'lbfgs';
options.display = 'on';
% options.displayImage = false;

[softmaxOptTheta, cost] = minFunc( @(p) softmaxCost(p, ...
                                   numClasses, inputSize, lambda, ...
                                   inputData, labels), ...                                   
                              theta, options);

%{
[softmaxOptTheta, cost] = minFunc( @(p) softmaxCost(p, ...
                                   numClasses, inputSize, lambda, ...
                                   inputData, labels), ...                                   
                              theta, options);

%}
softmaxModel.theta = reshape(softmaxOptTheta, numClasses, inputSize);
softmaxModel.inputSize = inputSize;
softmaxModel.numClasses = numClasses;
                          
end  

function [cost, grad] = softmaxCost(theta, numClasses, inputSize, lambda, data, labels)

theta = reshape(theta, numClasses, inputSize);

numCases = size(data, 2);

groundTruth = full(sparse(labels, 1:numCases, 1));
cost = 0;

thetagrad = zeros(numClasses, inputSize);
M = exp(theta*data);
M = bsxfun(@rdivide, M, sum(M));
cost = (-1/size(data,2)).*sum(sum(groundTruth.*log(M)));
cost = cost + (lambda/2).*sum(sum(theta.^2));

thetagrad = (-1/size(data,2)).*(((groundTruth-(M))*data') + (lambda*theta));

grad = [thetagrad(:)];
end



